<?php
    include("includes/utility.php");
    include("includes/header.php");
    include("includes/navbar.php");
    
?>


<div class="site-section" id="programs-section" style="background-color:#7FC7BB; padding-top:200px;">
      <div class="container" >
        <div class="row mb-5 justify-content-center" >
          <div class="col-lg-7 text-center"  data-aos="fade-up" data-aos-delay="" >
            <h2 class="section-title">Platforms</h2>
            <p>We provide here the platform to learn and organize your things!</p>
            <p>You can organize your Olympiad or Quiz on your own and also can create your own course here</p>
            <p>Best Platform to create and learn new things</p>
          </div>
        </div>
        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/undraw_youtube_tutorial.svg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
          <h2 class="text-black mb-4">Courses</h2>
            <p class="mb-4">Want to create or learn!</p>
            <a class="btn btn-primary" href="role_course.php" role="button">Click me!</a>
            



          </div>
        </div>

        

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/undraw_teacher.svg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
          <h2 class="text-black mb-4">Olympiad</h2>
            <p class="mb-4">Want to create or attempt Olympiad!</p>
            <a class="btn btn-primary" href="role_olympiad.php" role="button">Click me!</a>

           

          </div>
        </div>

      </div>
    </div>


         
<?php
      include("includes/footer.php");

?>