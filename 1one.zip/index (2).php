<script type="text/javascript">
window.location="login.php";

</script>