<?php
    include("includes/utility.php");
    include("includes/header.php");
    include("includes/navbar.php");
    
?>
<div class="intro-section" id="home-section">
      
      <div class="slide-1" style="background-image: url('images/hero_1.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12">
            <h1 data-aos="fade-up" data-aos-delay="100" style="text-align:center; padding-bottom:100px;">OSI NGO - MYPARLIAMENT</h1>
              <div class="row align-items-center">
                
                <div class="col-lg-12 mb-4">
               
                  <center><p class="mb-4"  data-aos="fade-up" data-aos-delay="200" id="para1" style="font-size:22px;"> Model Youth Parliament (MY Parliament) is an endeavor to set ‘policy’as an
                      agenda for the youth. MY Parliament with its awareness campaign aims to
                      create not an event but an environment where Indian youth talks about
                      policy and understands the process of policy making. Dream behind MY
                      Parliament is India where policies and policy making process becomes
                      meaningful household talk and we, the sovereign, the people, make India a
                      true participatory democracy. . Model Youth Parliament: Mock Parliament gives a platform for young
minds to discuss about legislations and also develop an interest towards
policies. Every year three simulations of parliamentary sessions are
organized in line with the Parliamentary sessions, namely budget, monsoon
and winter session. People across the country from different educational
background participate in this event to discuss current issues of national
importance.</p></center>
</div>
<div class="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="500">
</div>
</div>
</div>
            
</div>
</div>
</div>
</div>
<div class="site-section" id="teachers-section">
      <div class="container">

                                               <!-- our techer -->
<div class="row mb-5 justify-content-center">
          <div class="col-lg-7 mb-5 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">About Us</h2>
            <p class="mb-5">
           <center>|MISSION|</center>
To foster an environment
of active participation for
the youth in our democracy
 and to create a platform
for citizens’ engagement in
governance.<br><center>|VISION|</center>
We envision an India
where each and
every individual is
responsible for their
democratic rights and
is a participatory citizen
guided by the values of
the constitution.</p>
<p>"Starting the Programe
Which is much needed
in today system"</p>
<p>"We believe that one day this
model will have better discussion
than the original
Parliament"</p>
<p>As we can see MY Parliament and Governance Olympiad involves
scheduling an event, an online exam and MOOCs for learning of
participants.</p>
          </div>
        </div>

        

    



    <div class="site-section bg-light" id="contact-section">
      <div class="container">

        <div class="row justify-content-center">
          <div class="col-md-7">


            
            <h2 class="section-title mb-3">Contact Us</h2>
            <p class="mb-5">For any furthure queries can contact us!</p>
          
            <form method="POST" action="index.php" data-aos="fade">
              <div class="form-group row">
                <div class="col-md-6 mb-3 mb-lg-0">
                  <input type="text" class="form-control" name='fname' placeholder="First name">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control" name='lname' placeholder="Last name">
                </div>
              </div>

              <div class="form-group row">
              <div class="col-md-12">
                  <input type="email" class="form-control" name='email' placeholder="Email">
                </div>
              </div>

              <div class="form-group row">
              <div class="col-md-12">
                  <input type="text" name='subject' class="form-control" placeholder="Subject">
                </div>
                
              </div>
              <div class="form-group row">
                <div class="col-md-12">
                  <textarea class="form-control" name='message' id="" cols="30" rows="10" placeholder="Write your message here."></textarea>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  
                  <input type="submit" name='submit' class="btn btn-primary py-3 px-5 btn-block btn-pill" value="Send Message">
                </div>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
    
     
<?php
      include("includes/footer.php");


?>


  <?php
            
       

      include("connection.php");
        
      if(isset($_POST['submit'])){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];

       

        $sql = "INSERT INTO contact_us(fname, lname, email, subject, message) VALUES('$fname','$lname', '$email','$subject', '$message')";

        $res = mysqli_query($link, $sql);
      
      
      }



  ?>
