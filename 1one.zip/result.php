<?php
session_start();
include "connection.php";
$date=date("Y-m-d H:i:s");
$_SESSION["end_time"]=date("Y-m-d H:i:s",strtotime($date."+$_SESSION[exam_time] minutes"));

?>


<br>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Quiz System</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="stylesheet" href="css1/bootstrap.min.css">
    <link rel="stylesheet" href="css1/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">


</head>
<body style="background-color:#97B1C6;">

    <div class="all-content-wrapper">

        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="educate-icon educate-nav"></i>
												</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                            <li class="nav-item" style="padding-left:10px;"><button type="button" class="btn btn-danger" ><a href="select_exam.php" class="nav-link">Select Exam</a></button>
                                                </li>
                                                <li class="nav-item" style="padding-left:10px;"><button type="button" class="btn btn-danger" ><a href="old_exam_results.php" class="nav-link">Last Result</a></button>
                                                </li>
                                                <li class="nav-item" style="padding-left:10px;"><button type="button" class="btn btn-danger" ><a href="logout.php" class="nav-link">Logout</a></button>
                                                </li>
                                              
                                               
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">


                                                <li class="nav-item">
                                                    <!--<a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
															<img src="img/avatar-mini2.jpg" alt="" />
															<span class="admin-name"></span>
															<i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
														</a>-->
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="logout.php"><span class="edu-icon edu-user-rounded author-log-ic"></span>Logout</a>
                                                        </li>
                                                        
                                                    </ul>
                                                </li>
                                               
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
<br>
        <div class="row" style="margin: 0px; padding:0px; margin-bottom: 50px;">

            <div class="col-lg-6 col-lg-push-3" style="min-height: 500px; background-color: white;">
             <?php
             $correct=0;
             $wrong=0;

             if(isset($_SESSION["answer"]))
             {
                 for($i=1;$i<=sizeof($_SESSION["answer"]);$i++)
             {
                $answer="";
                $res=mysqli_query($link,"select * from questions where category='$_SESSION[exam_category]' && question_no=$i"); 
                while($row=mysqli_fetch_array($res))
                {
                    $answer=$row["answer"];
                }
                if(isset($_SESSION["answer"][$i]))
                {
                    if($answer==$_SESSION["answer"][$i])
                    {
                       $correct=$correct+1; 
                    }else{
                        $wrong=$wrong+1;
                    }
                }
                else{
                    $wrong=$wrong+1;
                }
             }
             }
                $count=0;
                $res=mysqli_query($link,"select * from questions where category='$_SESSION[exam_category]'");
                $count=mysqli_num_rows($res);
                $wrong=$count-$correct;
                echo "<br>"; echo "<br>";
                echo "<center>";
                echo "Total Questions=".$count;
                echo "<br>";
                echo "Correct Answer=".$correct;
                echo "<br>";
                echo "Wrong Answer=".$wrong;

                echo "</center>";
             ?>
        </div>
        </div>


<?php
if(isset($_SESSION["exam_start"]))
{
    $date=date("Y-m-d");
    mysqli_query($link,"insert into exam_results(id,username,exam_type,total_question,correct_answer,wrong_answer,exam_time) values(NULL,'$_SESSION[username]','$_SESSION[exam_category]','$count','$correct','$wrong','$date')") or die(mysqli_error($link));
}
if(isset($_SESSION["exam_start"]))
{
    unset($_SESSION["exam_start"]);
    ?>
    <script type="text/javascript">
    window.location.href=window.location.href;
    </script>
    <?php
}

?>

