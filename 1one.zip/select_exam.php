<?php
session_start();
if(!isset($_SESSION["username"]))
{
    ?>
    <script type="text/javascript">
    window.location="login.php";
    </script>
    <?php
}

?>


<?php
include "connection.php";

?>



<br>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Quiz System</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="stylesheet" href="css1/bootstrap.min.css">
    <link rel="stylesheet" href="css1/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">


</head>

<body style="background-color:#97B1C6;">

    <div class="all-content-wrapper">

        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="educate-icon educate-nav"></i>
												</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                            <li class="nav-item" style="padding-left:10px;"><button type="button" class="btn btn-danger" ><a href="select_exam.php" class="nav-link">Select Exam</a></button>
                                                </li>
                                                <li class="nav-item" style="padding-left:10px;"><button type="button" class="btn btn-danger" ><a href="old_exam_results.php" class="nav-link">Last Result</a></button>
                                                </li>
                                                <li class="nav-item" style="padding-left:10px;"><button type="button" class="btn btn-danger" ><a href="logout.php" class="nav-link">Logout</a></button>
                                                </li>
                                              
                                               
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">


                                                <li class="nav-item">
                                                   
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="logout.php"><span class="edu-icon edu-user-rounded author-log-ic"></span>Logout</a>
                                                        </li>
                                                        
                                                    </ul>
                                                </li>
                                               
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->

        <div class="row" style="margin: 0px; padding:0px; margin-bottom: 50px;">

            <div class="col-lg-6 col-lg-push-3" style="min-height: 500px;">
            <?php
             $res=mysqli_query($link, "select * from exam_category");
             while($row=mysqli_fetch_array($res))
             {
                 ?>
                    <input type="button" class="btn btn-success form-control" value="<?php echo $row["category"]; ?>" style="margin-top:10px; background-color:#A1A1A1; color: white" onclick="set_exam_type_session(this.value)">
                 <?php
             }


            ?>
            
            
            
            </div>
               
        </div>




<script type="text/javascript">
function set_exam_type_session(exam_category)
{
    var xmlhttp=new XMLHttpRequest();
    xmlhttp.onreadystatechange=function(){
        if(xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            
            window.location="dashboard.php";
        }
    };
    xmlhttp.open("GET","forajax/set_exam_type_session.php?exam_category="+ exam_category,true);
    xmlhttp.send(null);
}
</script>


        