<?php
	if(!isset($_REQUEST['submit']))
		die("access denied");
	else
	{
		include("connection_db.php");
		$sql = "INSERT INTO users(user_name, user_email_address, user_password) VALUES('".$_REQUEST['name']."', '".$_REQUEST['email']."', '".$_REQUEST['password']."' )";
		if($conn->query($sql))
		{
			$l = "location:../login.php?status=success";
			header($l);
		}
		else
		{
			$l = "location:../sign-up.php?s=fail";
			header($l);
		}
	}
?>