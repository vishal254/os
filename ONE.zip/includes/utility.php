<?php
	function baseurl()
	{
		return "http://localhost/OSI NGO/index.php";
	}
?>	