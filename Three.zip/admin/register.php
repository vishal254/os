<?php
session_start();
include "../connection.php"; 

?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
 

<style>
/* Full-width input fields */
    input[type=text], input[type=password] 
    {
      width: 90%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
    }

    input[type=text]:focus, input[type=password]:focus
    {
      background-color: #ddd;
      outline: none;
    }
    body 
    {
            background-color: mediumseagreen;
            font-family: 'Ubuntu', sans-serif;
     }

    form
    {
        margin-left: 8%;
        margin-right: 8%;
    }
    h1
    {
        font-size: 3em;
    }
    /* Overwrite default styles of hr */
    hr 
    {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
    }

    /* Set a style for the submit button */
    .registerbtn
    {
      background-color: mediumseagreen;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 93%;
      opacity: 0.9;
    }

    .registerbtn:hover
    {
      opacity: 1;
    }

    /* Add a blue text color to links */
    a 
    {
      color: dodgerblue;
    }

    /* Set a grey background color and center the text of the "sign in" section */
    .login 
    {

      text-align: center;
       margin-bottom: 20px;; 
       height: 30%;
    }

    .main 
    {
            background-color: #FFFFFF;
            width: 60%;
            height: 95%;
            margin: 2em auto;
            border-radius: 1.5em;
            box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
        }    
</style>

</head>
<body>
   


<div class="main">
       <form method="post" action='register.php'>
        <div class="container">
        <hr>
           <h1><center>Admin Registration</center></h1><hr>
           <p>Please fill in this form to create an account.</p><br>
           <label for="fname"><b>First name:</b></label><br>
           <input type="text" id="fname" name="firstname" placeholder="Enter Firstname" required><br>
           <label for="lname"><b>Last name:</b></label><br>
           <input type="text" id="lname" name="lastname" placeholder="Enter Lastname"  ><br> 
           <label for="username"><b>Username:</b></label><br>
           <input type="text" id="username" name="username" placeholder="Enter Username" required ><br>
           <label for="email"><b>Email:</b></label><br>
           <input type="text" placeholder="Enter Email" name="email" id="email" required><br>
           <label for="psw"><b>Password:</b></label><br>
           <input type="password" placeholder="Enter Password" name="password" id="psw" required><br>
           <label for="phone"><b>Contact:</b></label><br>
           <input type="text" id="phone" name="contact"  placeholder="Enter Contact" required><br>
          <button type="submit" name="registerbtn" class="registerbtn">Register</button>
          <div class="container login">
          <p>Already have an account? <a href="index.php">Log in</a>.</p>
          </div>
          <hr>
          </div>
       </form>
       </div>



</body>
</html>


<?php  



if(isset($_POST['registerbtn'])){
      $first=$_POST['firstname'];
      $last=$_POST['lastname'];
      $username=$_POST['username'];
      $pass=$_POST['password'];
      $email=$_POST['email'];
      $contact=$_POST['contact'];


      
      $sql = "INSERT INTO admin_login(firstname, lastname, username, password, email, contact) VALUES('$first','$last', '$username','$pass','$email','$contact')";
     

      $res = mysqli_query($link, $sql);

      if ($res == 1){
          ?>
                <script>
                  alert('Your Registration is succesfully done!')
                </script>
          <?php
     }

    

}

?>